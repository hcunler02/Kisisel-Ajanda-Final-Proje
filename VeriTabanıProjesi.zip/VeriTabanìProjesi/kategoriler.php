<?php
session_start();
// 1. BEKÇİ: Giriş yapmayanları ana sayfaya gönder (ARTIK TUTARLI: user_id KONTROLÜ)
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

include "baglanti.php";

// 2. KİMLİK: Giriş yapanın ID'sini al
$benim_id = $_SESSION['user_id'];

// ------------------------------------
// A. Kategori Ekleme (Create) - KİŞİYE ÖZEL
// ------------------------------------
if(isset($_POST['ekle'])) {
    $kategori_ad = $conn->real_escape_string($_POST['kategori_ad']);
    $renk_kodu = $_POST['renk_kodu'] ?: '#3788d8'; 

    // user_id'yi de ekliyoruz
    $sql = "INSERT INTO Kategoriler (kategori_ad, renk_kodu, user_id) VALUES ('$kategori_ad', '$renk_kodu', '$benim_id')";
    
    if($conn->query($sql)){
        echo "<p style='color:green;'>Kategori başarıyla eklendi.</p>";
    } else {
        echo "<p style='color:red;'>Hata: ".$conn->error."</p>";
    }
}

// ------------------------------------
// B. Kategori Silme (Delete) - GÜVENLİ
// ------------------------------------
if(isset($_GET['sil_kategori'])){
    $kategori_id = $_GET['sil_kategori'];
    
    // Sadece benim ID'me sahip kategoriyi sil
    $sql = "DELETE FROM Kategoriler WHERE kategori_id = $kategori_id AND user_id = $benim_id";
    
    if($conn->query($sql)){
        if ($conn->affected_rows > 0) {
            echo "<p style='color:orange;'>Kategori başarıyla silindi.</p>";
        } else {
            echo "<p style='color:red;'>Bu kategori size ait değil!</p>";
        }
    } else {
        echo "<p style='color:red;'>Silme Hatası: ".$conn->error."</p>";
    }
}

// ------------------------------------
// C. Kategori Güncelleme (Update) - GÜVENLİ
// ------------------------------------
if(isset($_POST['guncelle'])) {
    $id = $_POST['kategori_id'];
    $kategori_ad = $conn->real_escape_string($_POST['kategori_ad']);
    $renk_kodu = $_POST['renk_kodu'];

    // Sadece benim kategorimi güncelle
    $sql = "UPDATE Kategoriler SET kategori_ad = '$kategori_ad', renk_kodu = '$renk_kodu' WHERE kategori_id = $id AND user_id = $benim_id";
    
    if($conn->query($sql)){
        echo "<p style='color:green;'>Kategori başarıyla güncellendi.</p>";
    } else {
        echo "<p style='color:red;'>Güncelleme Hatası: ".$conn->error."</p>";
    }
}

include "header.php"; 

// ------------------------------------
// D. Güncelleme Formunu Göster (Edit) - GÜVENLİ
// ------------------------------------
if(isset($_GET['guncelle_kategori'])){
    $kategori_id = $_GET['guncelle_kategori'];
    
    // Sadece benim kategorimi getir
    $kategori_sorgu = $conn->query("SELECT * FROM Kategoriler WHERE kategori_id = $kategori_id AND user_id = $benim_id");
    
    // HATA DÜZELTME: $kategori_sorgu'nun başarılı olup olmadığını kontrol et
    if($kategori_sorgu && $kategori_sorgu->num_rows > 0){
        $edit_kat = $kategori_sorgu->fetch_assoc();
    ?>
        <h3>Kategori Güncelle: <?php echo $edit_kat['kategori_ad']; ?></h3>
        <form method="post">
            <input type="hidden" name="kategori_id" value="<?php echo $edit_kat['kategori_id']; ?>">
            Kategori Adı: <input type="text" name="kategori_ad" required value="<?php echo $edit_kat['kategori_ad']; ?>"><br>
            Renk Kodu: <input type="color" name="renk_kodu" value="<?php echo $edit_kat['renk_kodu']; ?>"><br>
            <input type="submit" name="guncelle" value="Kaydet">
        </form>
        <hr>
    <?php 
    } else {
        echo "<p style='color:red'>Bu kategoriye erişim yetkiniz yok.</p>";
    }
} 
?>

<h2>Kategori Ekle</h2>
<form method="post">
    Kategori Adı: <input type="text" name="kategori_ad" required><br>
    Renk Kodu: <input type="color" name="renk_kodu"><br>
    <input type="submit" name="ekle" value="Ekle">
</form>

<hr>

<h2>Kategorilerim</h2>
<ul>
<?php
// Read (Okuma) - KİŞİYE ÖZEL LİSTELEME
$sonuc = $conn->query("SELECT * FROM Kategoriler WHERE user_id = $benim_id");

// HATA DÜZELTME: $sonuc'un başarılı olup olmadığını kontrol et
if($sonuc && $sonuc->num_rows > 0) {
    while ($kat = $sonuc->fetch_assoc()) {
        echo "<li style='color:".$kat['renk_kodu'].";'>".$kat['kategori_ad']." 
        <a href='?guncelle_kategori=".$kat['kategori_id']."'>[Düzenle]</a> 
        <a href='?sil_kategori=".$kat['kategori_id']."' onclick='return confirm(\"Silmek istediğine emin misin?\")'>[Sil]</a></li>";
    }
} else {
    echo "Henüz kategori eklemediniz.";
}
?>
</ul>

<?php include "footer.php"; ?>