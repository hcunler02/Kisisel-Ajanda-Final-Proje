<?php
session_start(); 

// 1. BEKÇİ: Giriş yapmayanları ana sayfaya gönder (ARTIK TUTARLI: user_id KONTROLÜ)
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

include "baglanti.php";

// 2. KİMLİK TESPİTİ: Giriş yapan kişinin ID'sini al
$benim_id = $_SESSION['user_id']; 

// ------------------------------------
// A. Not Ekleme (Create) - KİŞİYE ÖZEL
// ------------------------------------
if(isset($_POST['ekle'])) {
    $etkinlik_id = $_POST['etkinlik_id'] ?? '';
    $icerik = $conn->real_escape_string($_POST['not_icerigi'] ?? '');

    if($etkinlik_id == '' || $icerik == '') {
        echo "<p style='color:red;'>Etkinlik ve içerik boş olamaz!</p>";
    } else {
        // user_id sütununa $benim_id değerini de ekliyoruz!
        $sql = "INSERT INTO Notlar (etkinlik_id, not_icerigi, user_id) VALUES ('$etkinlik_id', '$icerik', '$benim_id')";
        
        if($conn->query($sql)) {
            echo "<p style='color:green;'>Not başarıyla eklendi.</p>";
        } else {
            echo "<p style='color:red;'>Hata: " . $conn->error . "</p>";
        }
    }
}

// ------------------------------------
// B. Not Silme (Delete) - GÜVENLİ
// ------------------------------------
if(isset($_GET['sil_not'])){
    $not_id = $_GET['sil_not'];
    // Sadece 'not_id' yetmez, 'user_id' de tutmalı. 
    $sql = "DELETE FROM Notlar WHERE not_id = $not_id AND user_id = $benim_id";
    
    if($conn->query($sql)){
        // Etkilenen satır var mı?
        if ($conn->affected_rows > 0) {
            echo "<p style='color:orange;'>Not başarıyla silindi.</p>";
        } else {
            echo "<p style='color:red;'>Bu not size ait değil veya zaten silinmiş!</p>";
        }
    } else {
        echo "<p style='color:red;'>Silme Hatası: ".$conn->error."</p>";
    }
}

// ------------------------------------
// C. Not Güncelleme (Update) - GÜVENLİ
// ------------------------------------
if(isset($_POST['guncelle'])) {
    $id = $_POST['not_id'];
    $etkinlik_id = $_POST['etkinlik_id'];
    $icerik = $conn->real_escape_string($_POST['not_icerigi']);

    // Güncellerken de 'user_id' kontrolü yapıyoruz.
    $sql = "UPDATE Notlar SET etkinlik_id = $etkinlik_id, not_icerigi = '$icerik' WHERE not_id = $id AND user_id = $benim_id";
    
    if($conn->query($sql)){
        echo "<p style='color:green;'>Not başarıyla güncellendi.</p>";
    } else {
        echo "<p style='color:red;'>Güncelleme Hatası: ".$conn->error."</p>";
    }
}

include "header.php"; 

// ------------------------------------
// D. Güncelleme Formunu Göster (Edit)
// ------------------------------------
if(isset($_GET['guncelle_not'])){
    $not_id = $_GET['guncelle_not'];
    // Sadece benim notumu getir (AND user_id = $benim_id)
    $not_sorgu = $conn->query("SELECT * FROM Notlar WHERE not_id = $not_id AND user_id = $benim_id");
    
    if($not_sorgu->num_rows > 0){
        $edit_not = $not_sorgu->fetch_assoc();
        if($edit_not):
?>
    <h3>Not Güncelle</h3>
    <form method="post">
        <input type="hidden" name="not_id" value="<?php echo $edit_not['not_id']; ?>">
        Etkinlik:
        <select name="etkinlik_id" required>
            <option value="">Seçiniz</option>
            <?php
            // Sadece kendi etkinliklerini listele
            $etkinlikler = $conn->query("SELECT * FROM Etkinlikler WHERE kullanici_id = $benim_id");
            if($etkinlikler){
                while($e = $etkinlikler->fetch_assoc()) {
                    $selected = ($e['etkinlik_id'] == $edit_not['etkinlik_id']) ? 'selected' : '';
                    echo "<option value='".$e['etkinlik_id']."' $selected>".$e['baslik']."</option>";
                }
            }
            ?>
        </select><br>

        Not İçeriği: <textarea name="not_icerigi" required><?php echo $edit_not['not_icerigi']; ?></textarea><br>
        <input type="submit" name="guncelle" value="Kaydet">
    </form>
    <hr>
<?php 
        endif;
    } else {
        echo "<p style='color:red'>Bu not size ait değil veya bulunamadı.</p>";
    }
} 
?>

<h2>Not Ekle</h2>
<form method="post">
  Etkinlik:
  <select name="etkinlik_id" required>
    <option value="">Seçiniz</option>
    <?php
    // Sadece kendi etkinliklerini listele
    $etkinlikler_sorgu = "SELECT * FROM Etkinlikler WHERE kullanici_id = $benim_id ORDER BY baslangic_tarihi DESC";
    $etkinlikler = $conn->query($etkinlikler_sorgu);
    
    if($etkinlikler) {
        while($e = $etkinlikler->fetch_assoc()) {
            echo "<option value='".$e['etkinlik_id']."'>".$e['baslik']."</option>";
        }
    } else {
        echo "<option value=''>Etkinlikler yüklenemedi</option>";
    }
    ?>
  </select><br>

  Not İçeriği: <textarea name="not_icerigi" required></textarea><br>
  <input type="submit" name="ekle" value="Ekle">
</form>

<hr>

<h2>Notlarım (Sadece Size Ait Olanlar)</h2>
<ul>
<?php
// Read (Okuma) - KİŞİYE ÖZEL LİSTELEME
$sql = "
    SELECT n.not_id, n.not_icerigi, n.eklenme_tarihi, e.baslik 
    FROM Notlar n 
    JOIN Etkinlikler e ON n.etkinlik_id = e.etkinlik_id
    WHERE n.user_id = $benim_id
    ORDER BY n.eklenme_tarihi DESC
";

$sonuc = $conn->query($sql);

// HATA DÜZELTME: $sonuc'un başarılı olup olmadığını kontrol et
if($sonuc && $sonuc->num_rows > 0) { 
    while ($satir = $sonuc->fetch_assoc()) {
        echo "<li>".$satir["not_id"]." - Etkinlik: ".$satir["baslik"]." | ".$satir["not_icerigi"]." | ".$satir["eklenme_tarihi"]." ";
        // İşlemler
        echo "<a href='?guncelle_not=".$satir['not_id']."'>[Düzenle]</a> ";
        echo "<a href='?sil_not=".$satir['not_id']."' onclick='return confirm(\"Bu notu silmek istediğinizden emin misiniz?\")'>[Sil]</a></li>";
    }
} else {
    echo "<p>Henüz hiç not eklemediniz.</p>";
}
?>
</ul>

<?php include "footer.php"; ?>