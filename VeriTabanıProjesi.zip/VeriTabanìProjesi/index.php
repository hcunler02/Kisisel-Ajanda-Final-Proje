<?php
session_start();
require_once 'baglanti.php'; // Veritabanı bağlantısı

// --- 1. ÇIKIŞ YAPMA İŞLEMİ (Linke tıklandıysa) ---
if (isset($_GET['cikis'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}

// --- 2. GİRİŞ YAPMA İŞLEMİ (Form gönderildiyse) ---
$hata = "";
if (isset($_POST['giris_yap'])) {
    // Formdan gelenleri temizle
    $kullanici = trim($_POST['kullanici_adi']);
    $sifre     = trim($_POST['sifre']);

    // Kullanıcıyı veritabanında ara
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $kullanici);
    $stmt->execute();
    $sonuc = $stmt->get_result();

    // Kullanıcı bulundu mu? (HATA KONTROLÜ İLE GÜVENLİK)
    // Eğer sorgu başarılı olduysa ($sonuc TRUE döndüyse) VE satır varsa devam et.
    if ($sonuc && $sonuc->num_rows > 0) { 
        $kayit = $sonuc->fetch_assoc();
        
        // Şifreyi Kontrol Et (Hashlenmiş şifre ile kıyasla)
        if (password_verify($sifre, $kayit['password'])) {
            // ŞİFRE DOĞRU! Giriş kartını (Session) ver
            $_SESSION['giris_var'] = true;
            $_SESSION['user_id']   = $kayit['id'];      // Kimlik no'yu hafızaya al
            $_SESSION['username']  = $kayit['username']; // İsmi hafızaya al
            
            header("Location: index.php"); // Sayfayı yenile
            exit;
        } else {
            $hata = "Şifre hatalı!";
        }
    } else { 
        $hata = "Böyle bir kullanıcı bulunamadı.";
    }
}

// --- 3. GÜVENLİK DUVARI (KİLT) ---
// Eğer giriş kartı yoksa, aşağıyı gösterme!
if (!isset($_SESSION['giris_var'])) {
?>
    <!DOCTYPE html>
    <html lang="tr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Giriş Yap</title>
        <style>
            body { font-family: 'Segoe UI', sans-serif; background: #e9ecef; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
            .login-kutu { background: white; padding: 40px; border-radius: 10px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); width: 320px; text-align: center; }
            h2 { color: #333; margin-bottom: 20px; }
            input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; }
            button { width: 100%; padding: 12px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; font-weight: bold; transition: 0.3s; }
            button:hover { background: #0056b3; }
            .hata { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px; font-size: 14px; }
            a { text-decoration: none; color: #007bff; font-size: 14px; }
            a:hover { text-decoration: underline; }
        </style>
    </head>
    <body>
        <div class="login-kutu">
            <h2>🔐 Güvenli Giriş</h2>
            <?php if($hata) echo "<div class='hata'>$hata</div>"; ?>
            
            <form method="post">
                <input type="text" name="kullanici_adi" placeholder="Kullanıcı Adı" required autocomplete="off">
                <input type="password" name="sifre" placeholder="Şifre" required>
                <button type="submit" name="giris_yap">Giriş Yap</button>
            </form>
            
            <br>
            <a href="kayit.php">Hesabın yok mu? Kayıt Ol</a>
        </div>
    </body>
    </html>
<?php
    exit(); // DUR! Buradan aşağısını okuma.
}
?>

<?php include "header.php"; ?>

<div style="padding: 20px;">
    <h2>Hoşgeldin, <?php echo htmlspecialchars($_SESSION['username']); ?>! 👋</h2>
    <p>Kişisel ajandanıza göz atabilir veya yeni etkinlikler ve notlar ekleyebilirsiniz.</p>
    
    <a href="index.php?cikis=1" style="color:red; text-decoration:none; font-weight:bold;">[ Güvenli Çıkış Yap ]</a>
</div>

<?php include "footer.php"; ?>