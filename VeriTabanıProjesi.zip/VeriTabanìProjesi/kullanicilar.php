<?php
session_start();

// 1. OTURUM BEKÇİSİ (AUTHORIZATION)
// Eğer session'da kullanıcı ID'si yoksa, login sayfasına at
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Giriş yapan kullanıcının ID'sini alıyoruz
$benim_id = $_SESSION['user_id']; 

include "baglanti.php";

// NOT: Bu sayfa artık Kişisel Rehber (Kişi Yönetimi) CRUD'u olarak çalışacaktır.
// Rehberdeki her kişi, onu ekleyen kullanıcıya (user_id) bağlıdır.


// ------------------------------------
// A. Kişi Ekleme (CREATE) - KİŞİYE ÖZEL
// ------------------------------------
if(isset($_POST['ekle'])) {
    // Verileri al ve temizle
    $ad = $conn->real_escape_string($_POST['ad']);
    $soyad = $conn->real_escape_string($_POST['soyad']);
    $email = $conn->real_escape_string($_POST['email']);
    $telefon = $conn->real_escape_string($_POST['telefon'] ?? '');
    
    // SQL: Rehbere eklediğimiz kişiye ek olarak, bu kişiyi kimin eklediğini (user_id) de kaydediyoruz.
    $sql = "INSERT INTO Kullanicilar (ad, soyad, email, telefon, user_id) VALUES ('$ad', '$soyad', '$email', '$telefon', '$benim_id')";
    
    if($conn->query($sql)){
        echo "<p style='color:green;'>✅ Kişi başarıyla rehbere eklendi.</p>";
    } else {
        echo "<p style='color:red;'>Hata: ".$conn->error."</p>";
    }
}


// ------------------------------------
// B. Kişi Silme (DELETE) - GÜVENLİ
// ------------------------------------
if(isset($_GET['sil_kullanici'])){
    $kullanici_id = $_GET['sil_kullanici'];
    
    // KRİTİK GÜVENLİK: Sadece benim eklediğim kişiyi silebiliriz.
    $sql = "DELETE FROM Kullanicilar WHERE kullanici_id = $kullanici_id AND user_id = $benim_id";
    
    if($conn->query($sql)){
        if ($conn->affected_rows > 0) {
            echo "<p style='color:orange;'>🗑️ Kişi rehberden silindi.</p>";
        } else {
            // Başkasının kişisini silmeye çalışırsa bu mesaj çıkar
            echo "<p style='color:red;'>❌ Bu kişiyi silme yetkiniz yok!</p>";
        }
    } else {
        echo "<p style='color:red;'>Silme Hatası: ".$conn->error."</p>";
    }
}


// ------------------------------------
// C. Kişi Güncelleme (UPDATE) - GÜVENLİ
// ------------------------------------
if(isset($_POST['guncelle'])) {
    $id = $_POST['kullanici_id'];
    // Verileri al ve temizle
    $ad = $conn->real_escape_string($_POST['ad']);
    $soyad = $conn->real_escape_string($_POST['soyad']);
    $email = $conn->real_escape_string($_POST['email']);
    $telefon = $conn->real_escape_string($_POST['telefon'] ?? '');

    // KRİTİK GÜVENLİK: Sadece benim eklediğim kişiyi güncelleyebiliriz.
    $sql = "UPDATE Kullanicilar SET ad = '$ad', soyad = '$soyad', email = '$email', telefon = '$telefon' 
            WHERE kullanici_id = $id AND user_id = $benim_id";

    if($conn->query($sql)){
        echo "<p style='color:green;'>🔄 Kişi bilgileri başarıyla güncellendi.</p>";
    } else {
        echo "<p style='color:red;'>Güncelleme Hatası: ".$conn->error."</p>";
    }
}

include "header.php"; 

// ------------------------------------
// D. Güncelleme Formunu Göster (READ for EDIT) - GÜVENLİ
// ------------------------------------
if(isset($_GET['guncelle_kullanici'])){
    $kullanici_id = $_GET['guncelle_kullanici'];
    
    // KRİTİK GÜVENLİK: Sadece benim eklediğim kişiyi getir.
    $kullanici_sorgu = $conn->query("SELECT * FROM Kullanicilar WHERE kullanici_id = $kullanici_id AND user_id = $benim_id");
    
    if($kullanici_sorgu && $kullanici_sorgu->num_rows > 0){
        $edit_kull = $kullanici_sorgu->fetch_assoc();
    ?>
        <div style="background:#f9f9f9; padding:20px; border:1px solid #ddd; border-radius:5px; margin-bottom:20px;">
            <h3>✏️ Kişi Güncelle: <?php echo $edit_kull['ad']." ".$edit_kull['soyad']; ?></h3>
            <form method="post">
                <input type="hidden" name="kullanici_id" value="<?php echo $edit_kull['kullanici_id']; ?>">
                Ad: <input type="text" name="ad" required value="<?php echo $edit_kull['ad']; ?>"><br>
                Soyad: <input type="text" name="soyad" required value="<?php echo $edit_kull['soyad']; ?>"><br>
                Email: <input type="email" name="email" required value="<?php echo $edit_kull['email']; ?>"><br>
                Telefon: <input type="text" name="telefon" value="<?php echo $edit_kull['telefon']; ?>"><br>
                <input type="submit" name="guncelle" value="Kaydet" style="background:#007bff; color:white; border:none; padding:10px 20px; cursor:pointer;">
            </form>
        </div>
        <hr>
    <?php 
    } else {
        echo "<p style='color:red'>Bu kişiye erişim yetkiniz yok veya kişi bulunamadı.</p>";
    }
} 
?>

<h2>👥 Yeni Kişi Ekle (Rehberime)</h2>
<form method="post">
    Ad: <input type="text" name="ad" required><br>
    Soyad: <input type="text" name="soyad" required><br>
    Email: <input type="email" name="email" required><br>
    Telefon: <input type="text" name="telefon"><br>
    <input type="submit" name="ekle" value="Rehbere Ekle" style="background:#28a745; color:white; border:none; padding:10px 20px; cursor:pointer;">
</form>

<hr>

<h2>Rehberimdeki Kişiler</h2>
<table style="width: 100%; border-collapse: collapse;">
    <tr style="background-color: #f2f2f2;">
        <th style="padding:10px; border:1px solid #ddd;">ID</th>
        <th style="padding:10px; border:1px solid #ddd;">Ad Soyad</th>
        <th style="padding:10px; border:1px solid #ddd;">Email</th>
        <th style="padding:10px; border:1px solid #ddd;">Telefon</th>
        <th style="padding:10px; border:1px solid #ddd;">İşlemler</th>
    </tr>
<?php
// Read (Okuma) - KİŞİYE ÖZEL LİSTELEME
// SADECE BENİM EKLEDİĞİM KİŞİLERİ GÖSTER
$sonuc = $conn->query("SELECT * FROM Kullanicilar WHERE user_id = $benim_id ORDER BY soyad ASC");

if($sonuc && $sonuc->num_rows > 0) {
    while ($kull = $sonuc->fetch_assoc()) {
        echo "<tr>";
        echo "<td style='padding:8px; border:1px solid #ddd;'>".$kull['kullanici_id']."</td>";
        echo "<td style='padding:8px; border:1px solid #ddd; font-weight:bold;'>".$kull['ad']." ".$kull['soyad']."</td>";
        echo "<td style='padding:8px; border:1px solid #ddd;'>".$kull['email']."</td>";
        echo "<td style='padding:8px; border:1px solid #ddd;'>".($kull['telefon'] ?? '-')."</td>";
        echo "<td style='padding:8px; border:1px solid #ddd;'>
            <a href='?guncelle_kullanici=".$kull['kullanici_id']."' style='text-decoration:none; color:blue;'>Düzenle</a> | 
            <a href='?sil_kullanici=".$kull['kullanici_id']."' onclick='return confirm(\"Bu kişiyi silmek istediğinizden emin misiniz?\")' style='text-decoration:none; color:red;'>Sil</a>
            </td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='5' style='text-align:center; padding:20px;'>Henüz rehberinize hiç kişi eklemediniz.</td></tr>";
}
?>
</table>

<?php include "footer.php"; ?>