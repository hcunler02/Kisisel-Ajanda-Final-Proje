<?php
// Hataları görmek için (Gerekirse kapatabilirsin)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "kisb4elajandcom_ajandacan"; 
$password = "hcanadyu1976."; // BURAYA KENDİ ŞİFRENİ YAZ
$dbname = "kisb4elajandcom_ajanda"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Baglanti hatasi: " . $conn->connect_error);
}

// Türkçe karakter sorunu olmaması için
$conn->set_charset("utf8mb4");
?>