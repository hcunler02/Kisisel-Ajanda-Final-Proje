<?php
session_start();
// 1. BEKÇİ: Giriş yapmayanları ana sayfaya gönder (ARTIK TUTARLI: user_id KONTROLÜ)
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

include "baglanti.php";

// 2. KİMLİK: Giriş yapanın ID'sini al
$benim_id = $_SESSION['user_id'];

include "header.php";

// ------------------------------------
// A. Etkinlik Oluşturma (Create) - KİŞİYE ÖZEL
// ------------------------------------
if(isset($_POST['ekle'])){
    // Kullanıcı ID'yi formdan değil, oturumdan alıyoruz!
    $kategori_id = $_POST['kategori_id'] ?: "NULL";
    $baslik = $conn->real_escape_string($_POST['baslik']); 
    $aciklama = $conn->real_escape_string($_POST['aciklama'] ?? "");
    $baslangic = $_POST['baslangic_tarihi'];
    $bitis = $_POST['bitis_tarihi'] ?: "NULL";
    $oncelik = $_POST['oncelik'];

    // SQL Sorgusu: kullanici_id yerine $benim_id değişkenini koyduk
    $sql = "INSERT INTO Etkinlikler 
        (kullanici_id, baslik, aciklama, baslangic_tarihi, bitis_tarihi, kategori_id, oncelik, tamamlandi_mi)
        VALUES ('$benim_id', '$baslik', '$aciklama', '$baslangic', ".($bitis=="NULL"?"NULL":"'".$bitis."'").", ".($kategori_id=="NULL"?"NULL":$kategori_id).", '$oncelik', 0)";
    
    if($conn->query($sql)){
        echo "<div style='padding:10px; background:#d4edda; color:#155724; margin-bottom:10px;'>✅ Etkinlik başarıyla eklendi.</div>";
    } else {
        echo "<div style='padding:10px; background:#f8d7da; color:#721c24;'>❌ Hata: ".$conn->error."</div>";
    }
}

// ------------------------------------
// B. Etkinlik Silme (Delete) - GÜVENLİ
// ------------------------------------
if(isset($_GET['sil_etkinlik'])){
    $etkinlik_id = $_GET['sil_etkinlik'];
    
    // Sadece benim ID'me sahip etkinliği sil (kullanici_id kontrolü)
    $sql = "DELETE FROM Etkinlikler WHERE etkinlik_id = $etkinlik_id AND kullanici_id = $benim_id";
    
    if($conn->query($sql)){
        if ($conn->affected_rows > 0) {
             echo "<div style='padding:10px; background:#fff3cd; color:#856404;'>🗑️ Etkinlik silindi.</div>";
        } else {
             echo "<div style='padding:10px; background:#f8d7da; color:#721c24;'>❌ Bu etkinlik size ait değil!</div>";
        }
    } else {
        echo "<p style='color:red;'>Silme Hatası: ".$conn->error."</p>";
    }
}

// ------------------------------------
// C. Etkinlik Güncelleme (Update) - GÜVENLİ
// ------------------------------------
if(isset($_POST['guncelle'])){
    $id = $_POST['etkinlik_id'];
    // Kullanıcı ID'yi güncellemiyoruz, etkinlik sahibini değiştiremezsin.
    $kategori_id = $_POST['kategori_id'] ?: "NULL";
    $baslik = $conn->real_escape_string($_POST['baslik']);
    $aciklama = $conn->real_escape_string($_POST['aciklama'] ?? "");
    $baslangic = $_POST['baslangic_tarihi'];
    $bitis = $_POST['bitis_tarihi'] ?: "NULL";
    $oncelik = $_POST['oncelik'];
    $tamamlandi = isset($_POST['tamamlandi_mi']) ? 1 : 0;

    // Sadece benim etkinliğimi güncelle (AND kullanici_id = $benim_id)
    $sql = "UPDATE Etkinlikler SET
        baslik = '$baslik', 
        aciklama = '$aciklama', 
        baslangic_tarihi = '$baslangic', 
        bitis_tarihi = ".($bitis=="NULL"?"NULL":"'".$bitis."'").",
        kategori_id = ".($kategori_id=="NULL"?"NULL":$kategori_id).", 
        oncelik = '$oncelik', 
        tamamlandi_mi = $tamamlandi
        WHERE etkinlik_id = $id AND kullanici_id = $benim_id";

    if($conn->query($sql)){
        echo "<div style='padding:10px; background:#d4edda; color:#155724;'>🔄 Etkinlik güncellendi.</div>";
    } else {
        echo "<p style='color:red;'>Güncelleme Hatası: ".$conn->error."</p>";
    }
}


// ------------------------------------
// D. Güncelleme Formunu Göster (Edit) - GÜVENLİ
// ------------------------------------
if(isset($_GET['guncelle_etkinlik'])){
    $etkinlik_id = $_GET['guncelle_etkinlik'];
    // Sadece benim etkinliğimi getir
    $etkinlik_sorgu = $conn->query("SELECT * FROM Etkinlikler WHERE etkinlik_id = $etkinlik_id AND kullanici_id = $benim_id");
    
    if($etkinlik_sorgu && $etkinlik_sorgu->num_rows > 0){ // HATA DÜZELTME
        $edit_etkinlik = $etkinlik_sorgu->fetch_assoc();
?>
    <div style="background:#f9f9f9; padding:20px; border:1px solid #ddd; border-radius:5px; margin-bottom:20px;">
        <h3>✏️ Etkinlik Güncelle: <?php echo $edit_etkinlik['baslik']; ?></h3>
        <form method="post">
            <input type="hidden" name="etkinlik_id" value="<?php echo $edit_etkinlik['etkinlik_id']; ?>">
            
            Kategori:
            <select name="kategori_id">
                <option value="">Kategori Seçiniz</option>
                <?php
                // Sadece BENİM kategorilerimi listele
                $kat = $conn->query("SELECT * FROM Kategoriler WHERE user_id = $benim_id");
                while($k = $kat->fetch_assoc()){
                    $selected = ($k['kategori_id'] == $edit_etkinlik['kategori_id']) ? 'selected' : '';
                    echo "<option value='".$k['kategori_id']."' $selected>".$k['kategori_ad']."</option>";
                }
                ?>
            </select><br><br>

            Başlık: <input type="text" name="baslik" required value="<?php echo $edit_etkinlik['baslik']; ?>" style="width:100%"><br><br>
            Açıklama: <textarea name="aciklama" style="width:100%"><?php echo $edit_etkinlik['aciklama']; ?></textarea><br><br>
            
            Başlangıç Tarihi: <input type="datetime-local" name="baslangic_tarihi" required value="<?php echo str_replace(' ', 'T', $edit_etkinlik['baslangic_tarihi']); ?>"><br><br>
            Bitiş Tarihi: <input type="datetime-local" name="bitis_tarihi" value="<?php echo $edit_etkinlik['bitis_tarihi'] ? str_replace(' ', 'T', $edit_etkinlik['bitis_tarihi']) : ''; ?>"><br><br>
            
            Öncelik:
            <select name="oncelik">
                <option value="düşük" <?php echo ($edit_etkinlik['oncelik'] == 'düşük') ? 'selected' : ''; ?>>Düşük</option>
                <option value="orta" <?php echo ($edit_etkinlik['oncelik'] == 'orta') ? 'selected' : ''; ?>>Orta</option>
                <option value="yüksek" <?php echo ($edit_etkinlik['oncelik'] == 'yüksek') ? 'selected' : ''; ?>>Yüksek</option>
            </select><br><br>
            
            <label style="cursor:pointer;">
                <input type="checkbox" name="tamamlandi_mi" value="1" <?php echo $edit_etkinlik['tamamlandi_mi'] ? 'checked' : ''; ?>> 
                Bu etkinlik tamamlandı mı?
            </label><br><br>

            <input type="submit" name="guncelle" value="Güncellemeyi Kaydet" style="background:#007bff; color:white; border:none; padding:10px 20px; cursor:pointer;">
        </form>
    </div>
<?php 
    } else {
        echo "<p style='color:red'>Bu etkinliğe erişim yetkiniz yok.</p>";
    }
} 
?>

<h2>📅 Yeni Etkinlik Ekle</h2>
<form method="post" style="margin-bottom:30px;">
    Kategori:
    <select name="kategori_id">
        <option value="">Kategori Seçiniz (Opsiyonel)</option>
        <?php
        // Sadece BENİM kategorilerimi getir
        $kat = $conn->query("SELECT * FROM Kategoriler WHERE user_id = $benim_id");
        if($kat && $kat->num_rows > 0){ // HATA DÜZELTME
            while($k = $kat->fetch_assoc()){
                echo "<option value='".$k['kategori_id']."'>".$k['kategori_ad']."</option>";
            }
        } else {
            echo "<option value=''>Önce Kategori Ekleyin</option>";
        }
        ?>
    </select><br><br>

    Başlık: <input type="text" name="baslik" required placeholder="Örn: Toplantı"><br><br>
    Açıklama: <textarea name="aciklama" placeholder="Detaylar..."></textarea><br><br>
    Başlangıç Tarihi: <input type="datetime-local" name="baslangic_tarihi" required><br><br>
    Bitiş Tarihi: <input type="datetime-local" name="bitis_tarihi"><br><br>
    Öncelik:
    <select name="oncelik">
        <option value="düşük">Düşük</option>
        <option value="orta" selected>Orta</option>
        <option value="yüksek">Yüksek</option>
    </select><br><br>

    <input type="submit" name="ekle" value="Etkinlik Ekle" style="background:#28a745; color:white; border:none; padding:10px 20px; cursor:pointer;">
</form>

<hr>
<h2>📋 Etkinliklerim</h2>
<table style="width: 100%; border-collapse: collapse;">
    <tr style="background-color: #f2f2f2;">
        <th style="padding:10px; border:1px solid #ddd;">ID</th>
        <th style="padding:10px; border:1px solid #ddd;">Başlık</th>
        <th style="padding:10px; border:1px solid #ddd;">Açıklama</th>
        <th style="padding:10px; border:1px solid #ddd;">Kategori</th>
        <th style="padding:10px; border:1px solid #ddd;">Başlangıç</th>
        <th style="padding:10px; border:1px solid #ddd;">Durum</th>
        <th style="padding:10px; border:1px solid #ddd;">İşlemler</th>
    </tr>
    <?php
    // Read (Okuma) - KİŞİYE ÖZEL LİSTELEME
    // WHERE e.kullanici_id = $benim_id diyerek sadece senin etkinliklerini çekiyoruz
    $sql = "SELECT e.*, k.kategori_ad 
            FROM Etkinlikler e 
            LEFT JOIN Kategoriler k ON e.kategori_id = k.kategori_id 
            WHERE e.kullanici_id = $benim_id 
            ORDER BY e.baslangic_tarihi DESC";
            
    $res = $conn->query($sql);
    
    // HATA DÜZELTME: $res'in başarılı olup olmadığını kontrol et
    if($res && $res->num_rows > 0) { 
        while($row = $res->fetch_assoc()){
            $durum = $row['tamamlandi_mi'] ? '<span style="color:green">✅ Tamamlandı</span>' : '<span style="color:orange">⏳ Beklemede</span>';
            echo "<tr>";
            echo "<td style='padding:8px; border:1px solid #ddd;'>".$row['etkinlik_id']."</td>";
            echo "<td style='padding:8px; border:1px solid #ddd; font-weight:bold;'>".$row['baslik']."</td>";
            echo "<td style='padding:8px; border:1px solid #ddd;'>".$row['aciklama']."</td>";
            // Kategori rengini de ekleyelim mi? Şimdilik basit kalsın.
            echo "<td style='padding:8px; border:1px solid #ddd;'>".($row['kategori_ad'] ?? '-')."</td>";
            echo "<td style='padding:8px; border:1px solid #ddd;'>".$row['baslangic_tarihi']."</td>";
            echo "<td style='padding:8px; border:1px solid #ddd;'>".$durum."</td>";
            // İşlemler
            echo "<td style='padding:8px; border:1px solid #ddd;'>
                <a href='?guncelle_etkinlik=".$row['etkinlik_id']."' style='text-decoration:none; color:blue;'>Düzenle</a> | 
                <a href='?sil_etkinlik=".$row['etkinlik_id']."' onclick='return confirm(\"Bu etkinliği silmek istediğinizden emin misiniz?\")' style='text-decoration:none; color:red;'>Sil</a>
                </td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='7' style='text-align:center; padding:20px;'>Henüz hiç etkinlik eklemediniz.</td></tr>";
    }
    ?>
</table>

<?php include "footer.php"; ?>