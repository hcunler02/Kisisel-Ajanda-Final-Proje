<?php

require_once 'baglanti.php'; 



$mesaj = "";


if (isset($_POST['kullanici_adi'])) {
   
    $gelen_kullanici = trim($_POST['kullanici_adi']);
    $gelen_sifre     = trim($_POST['sifre']);
    

    if(!empty($gelen_kullanici) && !empty($gelen_sifre)) {
        
     
        $sifreli_hal = password_hash($gelen_sifre, PASSWORD_DEFAULT);

       
        $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
        
      
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $gelen_kullanici, $sifreli_hal);

        if ($stmt->execute()) {
            $mesaj = "<div style='color:green; padding:10px; border:1px solid green; border-radius:5px; margin-bottom:15px;'>✅ <b>Harika!</b> Kayıt başarılı. <a href='index.php'>Giriş Yapmak İçin Tıkla</a></div>";
        } else {
           
            $mesaj = "<div style='color:red;'>❌ Hata: Bu kullanıcı adı alınmış olabilir veya sistem hatası. (" . $conn->error . ")</div>";
        }
        $stmt->close();
        
    } else {
        $mesaj = "<div style='color:red;'>Lütfen kullanıcı adı ve şifre giriniz.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kayıt Ol</title>
    <style>
        body { font-family: sans-serif; background-color: #f4f6f8; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-box { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); width: 100%; max-width: 320px; text-align: center; }
        h2 { margin-bottom: 20px; color: #333; }
        input { width: 100%; padding: 12px; margin: 8px 0; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 12px; background-color: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; font-weight: bold; margin-top: 10px; }
        button:hover { background-color: #218838; }
        a { text-decoration: none; color: #007bff; font-size: 14px; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>

<div class="login-box">
    <h2>📝 Kayıt Ol</h2>
    <?php echo $mesaj; ?>
    <form method="post">
        <input type="text" name="kullanici_adi" placeholder="Kullanıcı Adı" required autocomplete="off">
        <input type="password" name="sifre" placeholder="Şifre" required autocomplete="new-password">
        <button type="submit">Kayıt Ol</button>
    </form>
    <br>
    <a href="index.php">Zaten üye misin? Giriş Yap</a>
</div>

</body>
</html>