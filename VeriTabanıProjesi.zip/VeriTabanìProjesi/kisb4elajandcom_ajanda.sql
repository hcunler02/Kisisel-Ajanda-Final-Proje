-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 14 Ara 2025, 11:54:29
-- Sunucu sürümü: 10.11.15-MariaDB
-- PHP Sürümü: 8.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `kisb4elajandcom_ajanda`
--

DELIMITER $$
--
-- Yordamlar
--
CREATE DEFINER=`kisb4elajandcom`@`localhost` PROCEDURE `sp_BugunkuEtkinlikler` (IN `kid` INT)   BEGIN
    SELECT e.baslik, e.baslangic_tarihi, k.kategori_ad 
    FROM Etkinlikler e 
    LEFT JOIN Kategoriler k ON e.kategori_id = k.kategori_id
    WHERE e.kullanici_id = kid AND DATE(e.baslangic_tarihi) = CURDATE();
END$$

CREATE DEFINER=`kisb4elajandcom`@`localhost` PROCEDURE `sp_EtkinlikEkle` (IN `kid` INT, IN `baslik` VARCHAR(100), IN `tarih` DATETIME)   BEGIN
    INSERT INTO Etkinlikler (kullanici_id, baslik, baslangic_tarihi) VALUES (kid, baslik, tarih);
END$$

CREATE DEFINER=`kisb4elajandcom`@`localhost` PROCEDURE `sp_Tamamla` (IN `eid` INT)   BEGIN
    UPDATE Etkinlikler SET tamamlandi_mi = 1 WHERE etkinlik_id = eid;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `Etkinlikler`
--

CREATE TABLE `Etkinlikler` (
  `etkinlik_id` int(11) NOT NULL,
  `kullanici_id` int(11) NOT NULL,
  `baslik` varchar(100) NOT NULL,
  `aciklama` mediumtext DEFAULT NULL,
  `baslangic_tarihi` datetime NOT NULL,
  `bitis_tarihi` datetime DEFAULT NULL,
  `kategori_id` int(11) DEFAULT NULL,
  `oncelik` enum('d???k','orta','y?ksek') DEFAULT 'orta',
  `tamamlandi_mi` tinyint(1) DEFAULT 0
) ;

--
-- Tablo döküm verisi `Etkinlikler`
--

INSERT INTO `Etkinlikler` (`etkinlik_id`, `kullanici_id`, `baslik`, `aciklama`, `baslangic_tarihi`, `bitis_tarihi`, `kategori_id`, `oncelik`, `tamamlandi_mi`) VALUES
(12, 3, 'İngilizce öğrenme', 'Herkes zamanında gelsin', '2025-12-03 22:08:00', '2025-12-26 22:08:00', 22, 'orta', 0),
(14, 2, 'ip atlama', 'gelin', '2025-12-03 22:36:00', '2025-12-04 22:36:00', 24, 'orta', 0),
(15, 2, 'Yüzme', 'Bone ,gözlük ve diğer ekipmanları getirmeyi unutmayın', '2025-12-03 22:41:00', '2025-12-03 23:30:00', 27, 'orta', 0),
(16, 2, 'Antreman', 'Gerekli Ekipmanları getirin', '2025-12-03 22:43:00', '2025-12-03 22:59:00', 28, 'orta', 0),
(17, 1, 'Antreman', 'Havlu ve Su getirmeyi unutma', '2025-12-03 22:46:00', '2025-12-03 22:59:00', 29, 'orta', 0),
(18, 1, 'Yüzme Etkinliği', 'Herkes gerekli ekipmanları getirsin', '2025-12-07 19:25:00', '2025-12-07 21:45:00', 30, '', 1),
(19, 1, 'VeriTabanı Ödevi', 'Dönem projesini teslim et', '2025-11-10 15:00:00', '2025-12-26 23:59:00', 31, '', 0),
(20, 2, 'Dişçi Randevusu', '6 aylık kontrol', '2025-12-22 10:30:00', NULL, 32, '', 0),
(21, 6, 'Sokak Basketbolu', 'Belirlenen saat ve tarihte herkes sahada olsun.', '2025-12-09 21:54:00', '2025-12-09 22:55:00', 33, 'orta', 0),
(22, 7, '50 Soru Çözme', 'Fen Bilimlerinden 50 adet soru çöz', '2025-12-11 13:00:00', '2025-12-11 22:00:00', 34, '', 1),
(23, 7, 'Sınıflar Arası Turnuva', 'Herkes maç saatinde okul bahçesinde olsun', '2025-12-12 11:00:00', NULL, 35, '', 1);

--
-- Tetikleyiciler `Etkinlikler`
--
DELIMITER $$
CREATE TRIGGER `trg_etkinlik_log` AFTER INSERT ON `Etkinlikler` FOR EACH ROW BEGIN
    INSERT INTO Log_Islemler (tablo_adi, islem_tipi, yeni_veri)
    VALUES ('Etkinlikler', 'INSERT', CONCAT('ID:', NEW.etkinlik_id, ' - ', NEW.baslik));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_etkinlik_sil_log` BEFORE DELETE ON `Etkinlikler` FOR EACH ROW BEGIN
    INSERT INTO Log_Islemler (tablo_adi, islem_tipi, eski_veri)
    VALUES ('Etkinlikler', 'DELETE', CONCAT('ID:', OLD.etkinlik_id, ' - ', OLD.baslik));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_etkinlik_update_log` AFTER UPDATE ON `Etkinlikler` FOR EACH ROW BEGIN
    INSERT INTO Log_Islemler (tablo_adi, islem_tipi, eski_veri, yeni_veri)
    VALUES (
        'Etkinlikler', 
        'UPDATE', 
        CONCAT('ID:', OLD.etkinlik_id, ' - ', OLD.baslik),
        CONCAT('ID:', NEW.etkinlik_id, ' - ', NEW.baslik)
    );
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `Hatirlaticilar`
--

CREATE TABLE `Hatirlaticilar` (
  `hatirlatici_id` int(11) NOT NULL,
  `etkinlik_id` int(11) NOT NULL,
  `hatirlatici_zamani` datetime NOT NULL,
  `mesaj` varchar(255) DEFAULT NULL,
  `gonderildi_mi` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `Kategoriler`
--

CREATE TABLE `Kategoriler` (
  `kategori_id` int(11) NOT NULL,
  `kategori_ad` varchar(50) NOT NULL,
  `renk_kodu` varchar(7) DEFAULT '#3788d8',
  `user_id` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `Kategoriler`
--

INSERT INTO `Kategoriler` (`kategori_id`, `kategori_ad`, `renk_kodu`, `user_id`) VALUES
(22, 'Dil Öğrenme', '#000000', 0),
(24, 'ip atlama', '#000000', 2),
(25, 'Dil Öğrenme', '#000000', 2),
(26, 'Piknik', '#c11a1a', 2),
(27, 'Yüzme', '#cdff1a', 2),
(28, 'Futbol Oynama', '#003cf0', 2),
(29, 'Futbol Oynama', '#f40101', 1),
(30, 'Yüzme', '#000000', 1),
(31, 'İş', '#f1bf09', 1),
(32, 'Sağlık', '#06c8ef', 2),
(33, 'Basketbol Oynama', '#0011ff', 6),
(34, 'Test  Çözme ', '#0076f5', 7),
(35, 'Futbol', '#0a26f5', 7);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `Kullanicilar`
--

CREATE TABLE `Kullanicilar` (
  `kullanici_id` int(11) NOT NULL,
  `ad` varchar(50) NOT NULL,
  `soyad` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefon` varchar(15) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `kayit_tarihi` datetime DEFAULT current_timestamp(),
  `aktif` tinyint(1) DEFAULT 1
) ;

--
-- Tablo döküm verisi `Kullanicilar`
--

INSERT INTO `Kullanicilar` (`kullanici_id`, `ad`, `soyad`, `email`, `telefon`, `user_id`, `kayit_tarihi`, `aktif`) VALUES
(3, 'Hüseyin Can', 'aslim', 'aslim@gmail.com', '', NULL, '2025-11-21 19:41:29', 1),
(4, 'ahmet', 'salim', 'salimabi@gmail.com', '123456892', NULL, '2025-11-21 19:42:11', 1),
(5, 'Ahmet', 'Tuttur', 'tuttur@gmail.com', '35467896421', NULL, '2025-11-24 21:40:15', 1),
(6, 'Ali', 'Demir', 'ali@gmail.com', '1234567890', 1, '2025-12-07 18:51:30', 1),
(7, 'Veli', 'Çakır', 'veli@gmail.com', '1234567890', 2, '2025-12-07 19:28:26', 1),
(9, 'Can', 'Can', 'can@gmail.com', '55458545455', 6, '2025-12-09 21:56:08', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `Log_Islemler`
--

CREATE TABLE `Log_Islemler` (
  `log_id` int(11) NOT NULL,
  `tablo_adi` varchar(50) NOT NULL,
  `islem_tipi` enum('INSERT','UPDATE','DELETE') NOT NULL,
  `eski_veri` text DEFAULT NULL,
  `yeni_veri` text DEFAULT NULL,
  `islem_tarihi` datetime DEFAULT current_timestamp(),
  `kullanici` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `Log_Islemler`
--

INSERT INTO `Log_Islemler` (`log_id`, `tablo_adi`, `islem_tipi`, `eski_veri`, `yeni_veri`, `islem_tarihi`, `kullanici`) VALUES
(1, 'Etkinlikler', 'INSERT', NULL, 'ID:4 - Test Etkinlik', '2025-11-21 18:18:49', NULL),
(2, 'Etkinlikler', 'UPDATE', 'ID:1 - Veritaban? Ödev Teslimi', 'ID:1 - Veritaban? Ödev Teslimi', '2025-11-21 18:18:49', NULL),
(3, 'Etkinlikler', 'UPDATE', 'ID:1 - Veritaban? Ödev Teslimi', 'ID:1 - Veritaban? Ödev Teslimi', '2025-11-21 18:18:49', NULL),
(4, 'Etkinlikler', 'INSERT', NULL, 'ID:5 - SP Test Etkinli?i', '2025-11-21 18:18:49', NULL),
(5, 'Etkinlikler', 'INSERT', NULL, 'ID:6 - Dil Ö?renme Okul?', '2025-11-21 19:48:37', NULL),
(6, 'Etkinlikler', 'INSERT', NULL, 'ID:7 - Piknik Vakti', '2025-11-21 20:08:46', NULL),
(7, 'Etkinlikler', 'INSERT', NULL, 'ID:8 - fena iskender yicez gelin', '2025-11-22 01:40:49', NULL),
(8, 'Etkinlikler', 'UPDATE', 'ID:8 - fena iskender yicez gelin', 'ID:8 - fena iskender yicez gelin', '2025-11-22 01:41:01', NULL),
(9, 'Etkinlikler', 'DELETE', 'ID:7 - Piknik Vakti', NULL, '2025-11-25 14:54:10', NULL),
(10, 'Etkinlikler', 'DELETE', 'ID:6 - Dil Ö?renme Okul?', NULL, '2025-11-25 15:15:52', NULL),
(11, 'Etkinlikler', 'DELETE', 'ID:8 - fena iskender yicez gelin', NULL, '2025-11-26 12:58:38', NULL),
(12, 'Etkinlikler', 'INSERT', NULL, 'ID:9 - ip atlama', '2025-11-27 20:03:12', NULL),
(13, 'Etkinlikler', 'UPDATE', 'ID:9 - ip atlama', 'ID:9 - ip atlama', '2025-11-27 20:05:22', NULL),
(14, 'Etkinlikler', 'INSERT', NULL, 'ID:10 - Yüzme', '2025-11-27 20:26:58', NULL),
(15, 'Etkinlikler', 'UPDATE', 'ID:10 - Yüzme', 'ID:10 - Yüzme', '2025-11-27 20:27:25', NULL),
(16, 'Etkinlikler', 'INSERT', NULL, 'ID:11 - ?ngilizce ö?renme', '2025-11-27 20:39:46', NULL),
(17, 'Etkinlikler', 'UPDATE', 'ID:11 - ?ngilizce ö?renme', 'ID:11 - ?ngilizce ö?renme', '2025-11-27 20:39:51', NULL),
(18, 'Etkinlikler', 'UPDATE', 'ID:11 - ?ngilizce ö?renme', 'ID:11 - ?ngilizce ö?renme', '2025-11-27 20:47:04', NULL),
(19, 'Etkinlikler', 'UPDATE', 'ID:11 - ?ngilizce ö?renme', 'ID:11 - ?ngilizce ö?renme', '2025-11-27 20:49:29', NULL),
(20, 'Etkinlikler', 'UPDATE', 'ID:11 - ?ngilizce ö?renme', 'ID:11 - ?ngilizce ö?renme', '2025-11-27 20:52:10', NULL),
(21, 'Etkinlikler', 'DELETE', 'ID:10 - Yüzme', NULL, '2025-11-28 17:46:39', NULL),
(22, 'Etkinlikler', 'DELETE', 'ID:9 - ip atlama', NULL, '2025-11-28 17:46:41', NULL),
(23, 'Etkinlikler', 'DELETE', 'ID:11 - ?ngilizce ö?renme', NULL, '2025-11-28 17:46:42', NULL),
(24, 'Etkinlikler', 'INSERT', NULL, 'ID:12 - ?ngilizce ö?renme', '2025-12-03 22:08:27', NULL),
(25, 'Etkinlikler', 'INSERT', NULL, 'ID:14 - ip atlama', '2025-12-03 22:40:04', NULL),
(26, 'Etkinlikler', 'INSERT', NULL, 'ID:15 - Yüzme', '2025-12-03 22:42:04', NULL),
(27, 'Etkinlikler', 'INSERT', NULL, 'ID:16 - Antreman', '2025-12-03 22:43:51', NULL),
(28, 'Etkinlikler', 'INSERT', NULL, 'ID:17 - Antreman', '2025-12-03 22:46:26', NULL),
(29, 'Etkinlikler', 'INSERT', NULL, 'ID:18 - Yüzme Etkinli?i', '2025-12-07 19:25:44', NULL),
(30, 'Etkinlikler', 'INSERT', NULL, 'ID:19 - VeriTaban? Ödevi', '2025-12-07 19:37:23', NULL),
(31, 'Etkinlikler', 'INSERT', NULL, 'ID:20 - Di?çi Randevusu', '2025-12-07 19:40:03', NULL),
(32, 'Etkinlikler', 'INSERT', NULL, 'ID:21 - Sokak Basketbolu', '2025-12-09 21:55:15', NULL),
(33, 'Etkinlikler', 'INSERT', NULL, 'ID:22 - 50 Soru Çözme', '2025-12-11 21:41:17', NULL),
(34, 'Etkinlikler', 'UPDATE', 'ID:22 - 50 Soru Çözme', 'ID:22 - 50 Soru Çözme', '2025-12-11 21:41:44', NULL),
(35, 'Etkinlikler', 'INSERT', NULL, 'ID:23 - S?n?flar Aras? Turnuva', '2025-12-11 21:43:58', NULL),
(36, 'Etkinlikler', 'UPDATE', 'ID:23 - S?n?flar Aras? Turnuva', 'ID:23 - S?n?flar Aras? Turnuva', '2025-12-11 21:44:15', NULL),
(37, 'Etkinlikler', 'UPDATE', 'ID:18 - Yüzme Etkinli?i', 'ID:18 - Yüzme Etkinli?i', '2025-12-11 21:50:53', NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `Notlar`
--

CREATE TABLE `Notlar` (
  `not_id` int(11) NOT NULL,
  `etkinlik_id` int(11) NOT NULL,
  `not_icerigi` mediumtext NOT NULL,
  `eklenme_tarihi` datetime DEFAULT current_timestamp(),
  `user_id` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `Notlar`
--

INSERT INTO `Notlar` (`not_id`, `etkinlik_id`, `not_icerigi`, `eklenme_tarihi`, `user_id`) VALUES
(5, 12, 'Herkese eğitim hakkında gerekli mesajlandırmalar sms üzerinden atılacaktır . Lütfen gün içerisinde smslerinizi kontrol ediniz', '2025-12-03 22:10:05', 1),
(6, 14, 'İp Atlamaya geç kalma', '2025-12-03 22:40:37', 2),
(7, 15, 'Size gönderilen mailleri ve smsleri okumanızı rica ederim', '2025-12-03 22:42:32', 2),
(8, 16, 'Su getirin', '2025-12-03 22:44:20', 2),
(9, 21, 'Maça gelirken su ve havlu  getirmeyi unutmayın', '2025-12-09 21:55:47', 6),
(10, 22, '25 doğru ve aşağısı için  ceza var. Her yanlış soru için ekstradan 5 soru ', '2025-12-11 21:42:36', 7),
(11, 23, 'Maçtan önce taktik çalışması yapılacak', '2025-12-11 21:44:40', 7);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'Ali', '$2y$10$mFXTWd8Z7WfUya0M4JzWfe.69P1oQOrFr/3vWvqwm4I2.y0cFywsS'),
(2, 'Veli', '$2y$10$sodEbL8I8YdA3nxPJ93AouDMIqox4pe.I2vJ72AeWjClpI0qaLaMy'),
(3, 'deneme', '$2y$10$O/rRl.YnxP9708foEzcsteNc2gx5fdJe52CyY9kgZ.RHvcLXsT91q'),
(6, 'Can', '$2y$10$PIPHMGbwwgT4Gg2j/oRFJ.HCjpT3K7bFCEhZBhTSHOhIrR5SjCDrO'),
(7, 'Muhammet', '$2y$10$u8y.OZjr/HUT0SUXTSHxLuqVCTl2IeOA.hvXuGGWNa7/ea2gwChta');

-- --------------------------------------------------------

--
-- Görünüm yapısı durumu `vw_KategoriIstatistik`
-- (Asıl görünüm için aşağıya bakın)
--
CREATE TABLE `vw_KategoriIstatistik` (
`kategori_ad` varchar(50)
,`etkinlik_sayisi` bigint(21)
);

-- --------------------------------------------------------

--
-- Görünüm yapısı durumu `vw_LogSon10`
-- (Asıl görünüm için aşağıya bakın)
--
CREATE TABLE `vw_LogSon10` (
`log_id` int(11)
,`tablo_adi` varchar(50)
,`islem_tipi` enum('INSERT','UPDATE','DELETE')
,`eski_veri` text
,`yeni_veri` text
,`islem_tarihi` datetime
,`kullanici` varchar(100)
);

-- --------------------------------------------------------

--
-- Görünüm yapısı durumu `vw_Tamamlanmamis`
-- (Asıl görünüm için aşağıya bakın)
--
CREATE TABLE `vw_Tamamlanmamis` (
`baslik` varchar(100)
,`ad` varchar(50)
,`soyad` varchar(50)
,`baslangic_tarihi` datetime
);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `Etkinlikler`
--
ALTER TABLE `Etkinlikler`
  ADD PRIMARY KEY (`etkinlik_id`),
  ADD KEY `kullanici_id` (`kullanici_id`),
  ADD KEY `kategori_id` (`kategori_id`);

--
-- Tablo için indeksler `Hatirlaticilar`
--
ALTER TABLE `Hatirlaticilar`
  ADD PRIMARY KEY (`hatirlatici_id`),
  ADD KEY `etkinlik_id` (`etkinlik_id`);

--
-- Tablo için indeksler `Kategoriler`
--
ALTER TABLE `Kategoriler`
  ADD PRIMARY KEY (`kategori_id`);

--
-- Tablo için indeksler `Kullanicilar`
--
ALTER TABLE `Kullanicilar`
  ADD PRIMARY KEY (`kullanici_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Tablo için indeksler `Log_Islemler`
--
ALTER TABLE `Log_Islemler`
  ADD PRIMARY KEY (`log_id`);

--
-- Tablo için indeksler `Notlar`
--
ALTER TABLE `Notlar`
  ADD PRIMARY KEY (`not_id`),
  ADD KEY `etkinlik_id` (`etkinlik_id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `Etkinlikler`
--
ALTER TABLE `Etkinlikler`
  MODIFY `etkinlik_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `Hatirlaticilar`
--
ALTER TABLE `Hatirlaticilar`
  MODIFY `hatirlatici_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `Kategoriler`
--
ALTER TABLE `Kategoriler`
  MODIFY `kategori_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- Tablo için AUTO_INCREMENT değeri `Kullanicilar`
--
ALTER TABLE `Kullanicilar`
  MODIFY `kullanici_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `Log_Islemler`
--
ALTER TABLE `Log_Islemler`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- Tablo için AUTO_INCREMENT değeri `Notlar`
--
ALTER TABLE `Notlar`
  MODIFY `not_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

-- --------------------------------------------------------

--
-- Görünüm yapısı `vw_KategoriIstatistik`
--
DROP TABLE IF EXISTS `vw_KategoriIstatistik`;

CREATE ALGORITHM=UNDEFINED DEFINER=`kisb4elajandcom`@`localhost` SQL SECURITY DEFINER VIEW `vw_KategoriIstatistik`  AS SELECT `k`.`kategori_ad` AS `kategori_ad`, count(`e`.`etkinlik_id`) AS `etkinlik_sayisi` FROM (`Kategoriler` `k` left join `Etkinlikler` `e` on(`k`.`kategori_id` = `e`.`kategori_id`)) GROUP BY `k`.`kategori_ad` ;

-- --------------------------------------------------------

--
-- Görünüm yapısı `vw_LogSon10`
--
DROP TABLE IF EXISTS `vw_LogSon10`;

CREATE ALGORITHM=UNDEFINED DEFINER=`kisb4elajandcom`@`localhost` SQL SECURITY DEFINER VIEW `vw_LogSon10`  AS SELECT `Log_Islemler`.`log_id` AS `log_id`, `Log_Islemler`.`tablo_adi` AS `tablo_adi`, `Log_Islemler`.`islem_tipi` AS `islem_tipi`, `Log_Islemler`.`eski_veri` AS `eski_veri`, `Log_Islemler`.`yeni_veri` AS `yeni_veri`, `Log_Islemler`.`islem_tarihi` AS `islem_tarihi`, `Log_Islemler`.`kullanici` AS `kullanici` FROM `Log_Islemler` ORDER BY `Log_Islemler`.`log_id` DESC LIMIT 0, 10 ;

-- --------------------------------------------------------

--
-- Görünüm yapısı `vw_Tamamlanmamis`
--
DROP TABLE IF EXISTS `vw_Tamamlanmamis`;

CREATE ALGORITHM=UNDEFINED DEFINER=`kisb4elajandcom`@`localhost` SQL SECURITY DEFINER VIEW `vw_Tamamlanmamis`  AS SELECT `e`.`baslik` AS `baslik`, `u`.`ad` AS `ad`, `u`.`soyad` AS `soyad`, `e`.`baslangic_tarihi` AS `baslangic_tarihi` FROM (`Etkinlikler` `e` join `Kullanicilar` `u` on(`e`.`kullanici_id` = `u`.`kullanici_id`)) WHERE `e`.`tamamlandi_mi` = 0 ;

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `Etkinlikler`
--
ALTER TABLE `Etkinlikler`
  ADD CONSTRAINT `Etkinlikler_ibfk_2` FOREIGN KEY (`kategori_id`) REFERENCES `Kategoriler` (`kategori_id`) ON DELETE SET NULL;

--
-- Tablo kısıtlamaları `Hatirlaticilar`
--
ALTER TABLE `Hatirlaticilar`
  ADD CONSTRAINT `Hatirlaticilar_ibfk_1` FOREIGN KEY (`etkinlik_id`) REFERENCES `Etkinlikler` (`etkinlik_id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `Notlar`
--
ALTER TABLE `Notlar`
  ADD CONSTRAINT `Notlar_ibfk_1` FOREIGN KEY (`etkinlik_id`) REFERENCES `Etkinlikler` (`etkinlik_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
