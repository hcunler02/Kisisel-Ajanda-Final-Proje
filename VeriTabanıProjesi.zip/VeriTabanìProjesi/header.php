<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kişisel Ajanda Yönetimi</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        header, footer { background: #3788d8; color: white; padding: 10px; }
        nav a { color: white; margin: 0 10px; text-decoration: none; }
        nav a:hover { text-decoration: underline; }
        input, select, textarea { margin-bottom: 10px; width: 300px; }
    </style>
</head>
<body>
<header>
    <h1>Kişisel Ajanda</h1>
    <nav>
        <a href="index.php">Ana Sayfa</a>
        <a href="kategoriler.php">Kategoriler</a>
        <a href="etkinlikler.php">Etkinlikler</a>
        <a href="notlar.php">Notlar</a>
        <a href="kullanicilar.php" style="font-weight: bold; color: #ffeb3b;">Kullanıcılar</a>
    </nav>
</header>
<hr>