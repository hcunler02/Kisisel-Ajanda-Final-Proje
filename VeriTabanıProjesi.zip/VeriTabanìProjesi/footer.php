<hr>
<footer>
    <p>&copy; 2025 Kişisel Ajanda</p>
</footer>
</body>
</html>
